import tkinter as tk
from tkinter import ttk
from tkinter import filedialog as fd
import re
import string


# Root window
root = tk.Tk()
root.title('Display a Text File')
root.resizable(False, False)
root.geometry('750x1050')

# Text editor
text = tk.Text(root, height=12)
text.grid(column=0, row=0, sticky='nsew')



def open_text_file():
    # file type
    filetypes = (
        ('text files', '*.txt'),
        ('All files', '.')
    )
    # show the open file dialog
    f = fd.askopenfile(filetypes=filetypes)
    # read the text file and show its content on the Text
    text.insert('1.0', f.readlines())


# open file button
open_button = ttk.Button(
    root,
    text='Open a File',
    command=open_text_file
)


open_button.grid(column=3, row=1)


def count_text_file():
	frequency = {}
	document_text = open('sam.txt', 'r')
	text_string = document_text.read().lower()
	match_pattern = re.findall(r'\b[a-z]{3,15}\b', text_string)
 
	for word in match_pattern:
		count = frequency.get(word,0)
		frequency[word] = count + 1
		frequency_list = frequency.keys()
 
	for words in frequency_list:
		print (words, frequency[words])

count_button = ttk.Button(
    root,
    text='Count a word',
    command=count_text_file
)

count_button.grid(column=3, row=2)



root.mainloop()
